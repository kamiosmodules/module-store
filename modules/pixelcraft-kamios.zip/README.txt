PixelCraft UI for KamiOS/CumOS-RE
Cyber Pixel Full Pixel Art edition with square purple Quick Settings tiles, black pixel-art icons, rounded purple sliders and stock typography.
Device testing required.

Included artwork:
- wallpaper.png: matching Cyber Pixel wallpaper (apply manually in Android wallpaper settings).
- thumbnail.png: 512x512 module store thumbnail.
- preview.png: promotional preview artwork.
Note: bundled wallpaper is not automatically applied; no verified wallpaper knob was found.
